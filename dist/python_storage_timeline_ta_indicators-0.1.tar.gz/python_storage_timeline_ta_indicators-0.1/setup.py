from setuptools import setup, find_packages

setup(name='python_storage_timeline_ta_indicators',
      version='0.1',
      author='Oleksandr Namchuk',
      author_email='c1l1rua@gmail.com',
      url='https://github.com/C1l1r/python_storage_timeline_ta_indicators',
      packages=find_packages(),
     )